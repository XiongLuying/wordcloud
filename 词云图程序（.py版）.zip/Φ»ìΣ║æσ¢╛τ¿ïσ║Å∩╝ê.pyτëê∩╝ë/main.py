import os
import jieba
from wordcloud import WordCloud, ImageColorGenerator
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from collections import Counter

#构建相对路径
import os
base_path = os.path.dirname(os.path.abspath(__file__))
relative_path = os.path.join(base_path, "setting")
#生成地址
stopwords_path = os.path.join(relative_path, "停用词.txt")
intactwords_path = os.path.join(relative_path, "自定义词典.txt")
font_path = os.path.join(relative_path, "simhei.ttf")


def load_stopwords(filename):
    """从文件中加载停用词列表"""
    with open(filename, 'r', encoding='utf-8') as file:
        stopwords = set(file.read().splitlines())
        print(stopwords)
    return stopwords

def load_intactwords(filename):
    with open(filename, 'r', encoding='utf-8') as iw_file:
        intact_words = set(iw_file.read().splitlines())
    return intact_words


def extract_pdf_names_from_literature(directory):
    """遍历名为'文献'的目录及其子目录，提取所有PDF文件的名称（不包含.pdf后缀）。"""
    pdf_names = []
    for root, dirs, files in os.walk(directory):
        if '文献' in root.split(os.path.sep):
            for file in files:
                if file.endswith('.pdf'):
                    name = os.path.splitext(file)[0].split('_')[0]
                    pdf_names.append(name)
    return pdf_names

def segment_text(text):
    """使用jieba进行分词处理。"""
    all_text= ' '.join(text)
    #设置自定义词典
    jieba.load_userdict(intactwords_path)
    #使用cut方法进行分词
    seg_list = jieba.cut(all_text, cut_all=False)  # 使用精确模式分词
    #设置停用词
    stop_words = load_stopwords(stopwords_path)
    words_filtered = [word for word in seg_list if word not in stop_words]
    #统计词频并输出到"词频统计.txt"中
    word_counts = Counter(words_filtered)
    sorted_word_counts = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
    with open('词频统计.txt', 'w', encoding='utf-8') as file:
        for word, freq in sorted_word_counts:
            file.write(f"'{word}': {freq}\n")
    return ' '.join(words_filtered)


def create_word_cloud(names, font_path):
    """根据提供的名字列表，先进行分词处理，然后创建词云图并显示，支持中文显示。"""


    # 对所有标题进行分词
    segmented_texts = segment_text(names)

    # 设置字体以支持中文显示
    font = FontProperties(fname=font_path)

    wordcloud = WordCloud(
        width=800,
        height=400,
        max_words=100,
        background_color='white',
        font_path=font_path,
    ).generate(segmented_texts)
    wordcloud.to_file('wordcloud.png')


if __name__ == "__main__":
    base_directory = '.'
    literature_directory = os.path.join(base_directory, '文献')

    if os.path.isdir(literature_directory):
        pdf_names = extract_pdf_names_from_literature(literature_directory)
        print("找到的PDF文件（位于'文献'及其子目录下）:", pdf_names)

        # 这里需要替换为你的中文字体文件路径
        if os.path.exists(font_path):
            create_word_cloud(pdf_names, font_path)
        else:
            print("字体文件不存在，请检查路径。")
    else:
        print("'文献'目录不存在，请检查路径。")